# Sub Shipyard #
sub shipyard {
	if ($F{'yard'} == 1) { &yard_buy; return }
	if ($F{'yard'} == 2) { &yard_sell; return }
	if ($F{'yard'} == 3) { &yard_rep; return }
print <<YARD;
���D��<br><form method=$method action=$seacgi>
<input type=hidden name=id value="$F{'id'}">
<input type=hidden name=ps value="$F{'ps'}">
<input type=hidden name=mode value="play">
<input type=hidden name=yard value="1">
<input type=submit value="�w��" class=button>
</form><form method=$method action=$seacgi>
<input type=hidden name=id value="$F{'id'}">
<input type=hidden name=ps value="$F{'ps'}">
<input type=hidden name=mode value="play">
<input type=hidden name=yard value="2">
<input type=submit value="���p" class=button>
</form><form method=$method action=$seacgi>
<input type=hidden name=id value="$F{'id'}">
<input type=hidden name=ps value="$F{'ps'}">
<input type=hidden name=mode value="play">
<input type=hidden name=yard value="3">
<input type=submit value="�C��" class=button></form>
YARD
}

# Sub Buy Yard #
sub yard_buy {
	my @yardline = &open_dat("$datadir/$yarddat");
	&form_table('up','100%',1);
	&reload;
	print qq|���D���F�w���@�@|;
	&submit_button;
	print qq|</td></tr><tr><td align=left>\n|;
	foreach (0 .. $#yardline) {
		($goods,$kind,$goods_img,$sale_area,$sale_port,$volume,$ship_hp,$knot,$price)
		= split(/<>/,$yardline[$_]);
		if ($sale_area =~ /$area/ || $sale_port =~ /$port/) {
			$checked = !$first ? ' checked' : '';
			$first = 1;
			&price_up;
			print qq|<input type=radio name=goods value="$_"$checked>|;
			print qq|<img src="$img/$goods_img" height=15>$goods�F$price G<br>|;
			if ($kind == 1) {
				print qq|[�ύځF$volume �ϋv�F$ship_hp ���x�F$knot]<br>\n|;
			}
			elsif ($kind == 2) {
				print qq|�퓬�́{$volume<br>\n|;
			}
			elsif ($kind == 3) {
				print qq|�w���́{$volume<br>\n|;
			}
			elsif ($kind == 4) {
				print qq|�q�C�́{$volume<br>\n|;
			}
		}
	}
	print qq|<input type=hidden name=yard value="1"><input type=hidden name=mode value="buy_ship">\n|;
	&id_ps;
	&form_table('down');
}

# Sub Price Up #
sub price_up {
	if ($kind == 2 || $kind == 3 || $kind ==4) {
		my $rate = $atk + $cmd + $nav;
		$price = int($price * exp($rate * 0.03 - 3))
	}
}

# Sub Buy Ship #
sub buy_ship {
	&get_me($F{'id'});
	if ($action ne $F{'reload'}) { &play; exit }
	&get_port($area,$port);
	&ship_data;
	my @yardline = &open_dat("$datadir/$yarddat");
	($goods,$kind,$goods_img,$sale_area,$sale_port,$volume,$ship_hp,$knot,$price)
	 = split(/<>/, $yardline[$F{'goods'}] );
	if ( $sale_area !~ /$area/ && $sale_port !~ /$port/ ) { &play("�s���ł�"); exit }
	&price_up;
	if ( $money < $price ) { &play("����������܂���"); exit }
	if ( $#ship_ind == 16 && $kind == 1 ) { &play("����ȏ�D�͔����܂���"); exit}
	if ( $kind == 1 && $#ship_ind < 16 ) {
		push(@ship_ind , "$goods_img,$volume,$ship_hp,$knot,$goods");
		&msg("$goods�𔃂��܂���");
		&add_record("$goods�� $price�� �w��")
	}
	elsif ( $kind == 2 ) {
		if ($atk >= $atk_limit) { &play("����ȏ�͖����ł�"); exit }
		$atk += $volume;
		&msg("�������܂���");
		&add_record("�퓬�� + $volume")
	}
	elsif ( $kind == 3 ) {
		if ($cmd >= $cmd_limit) { &play("����ȏ�͖����ł�"); exit }
		$cmd += $volume;
		&msg("�w���͂����܂�܂���");
		&add_record("�w���� + $volume")
	}
	elsif ( $kind == 4 ) {
		if ($nav >= $nav_limit) { &play("����ȏ�͖����ł�"); exit }
		$nav += $volume;
		&msg("�q�C�͂����܂�܂���");
		&add_record("�q�C�� + $volume")
	}
	$action = '';
	$money -= $price;
	&play;
}

# Sub Yard Sell #
sub yard_sell {
	if ( $#ship_ind < 0) { print qq|�D������܂���|; &return_button; return }
	my @yardline = &open_dat("$datadir/$yarddat");
	&form_table('up','100%',1);
	&reload;
	print qq|���D���F���p�@�@|;
	&submit_button;
	print qq|</td></tr><tr><td align=left>\n|;
	for ($i = 0; $i <= $#ship_ind; $i++) {
		($price) = map{ (split(/<>/))[8] } grep {$ship[$i][4] eq (split(/<>/,$_))[0]} @yardline;
		$price = int($price / 2);
		$checked = $i == 0 ? ' checked' : '';
		print qq|<input type=radio name=goods value="$i"$checked>|;
		print qq|$ship[$i][4]�F$price G<br>\n|;
		print qq|[�ύځF$ship[$i][1] �ϋv�F$ship[$i][2] ���x�F$ship[$i][3]]<br>|;
	}
	print qq|<input type=hidden name=yard value="2"><input type=hidden name=mode value="sell_ship">\n|;
	&id_ps;
	&form_table('down');
}

# Sub Sell Ship #
sub sell_ship {
	&get_me($F{'id'});
	if ($action ne $F{'reload'}) { &play; exit }
	&ship_data;
	&fleet;
	&load_data;
	if ( ($total - $total_load - $food - $sailor - $ship[$F{'goods'}][1]) < 0 ) {
		&play("�c�ωׂ�����܂���");
		return
	}
	$action = '';
	my @yardline = &open_dat("$datadir/$yarddat");
	($price) = map{ (split(/<>/))[8] } grep {$ship[$F{'goods'}][4] eq (split(/<>/,$_))[0]} @yardline;
	splice(@ship_ind , $F{'goods'} ,1);
	my $upmoney = int($price / 2);
	$money += $upmoney;
	&msg("$ship[$F{'goods'}][4]�𔄋p���܂���");
	&add_record("$ship[$F{'goods'}][4]�� $upmoney�� ���p");
	&play;
}

# Sub Yard Repair #
sub yard_rep {
	if ( $#ship_ind < 0) { print qq|�D������܂���|; &return_button; return }
	my @yardline = &open_dat("$datadir/$yarddat");
	&form_table('up','100%',1);
	&reload;
	print qq|���D���F�C���@�@|;
	&submit_button;
	print qq|</td></tr><tr><td align=left>\n|;
	for ($i = 0; $i <= $#ship_ind; $i++) {
		($max_hp,$price) = map{ (split(/<>/))[6,8] } grep {$ship[$i][4] eq (split(/<>/,$_))[0]} @yardline;
		if (!$max_hp) { $max_hp = $ship[$F{'goods'}][1] * 0.2; $price = $ship[$F{'goods'}][1] * 10000; }
		if ($max_hp <= $ship[$i][2]) { next }
		$price = $max_hp ? int($price * 0.03 / ($ship[$i][2] / $max_hp)) : 0;
		if ($ship[$i][1] > 500) { $down = $ship[$i][1] - 20 }
		elsif ($ship[$i][1] > 100) { $down = $ship[$i][1] - 10 }
		else { $down = $ship[$i][1] }
		$checked = !$f ? ' checked' : '';
		$f = 1;
		print qq|<input type=radio name=goods value="$i"$checked>|;
		print qq|$ship[$i][4]�F$price G<br>\n|;
		print qq|[�ύځF$ship[$i][1] �ϋv�F$ship[$i][2] ���x�F$ship[$i][3]]<br>|;
		print qq|�C����@[�ύځF$down �ϋv�F$max_hp]<br>|;
	}
	print qq|�C���ł���D�͂���܂���<input type=hidden name=mode value="play">\n| if !$f;
	print qq|<input type=hidden name=yard value="3"><input type=hidden name=mode value="rep_ship">\n| if $f;
	&id_ps;
	&form_table('down');
}

# Sub Repair Ship #
sub rep_ship {
	&get_me($F{'id'});
	if ($action ne $F{'reload'}) { &play; exit }
	&ship_data;
	&fleet;
	&load_data;
	my @yardline = &open_dat("$datadir/$yarddat");
	($max_hp,$price) = map{ (split(/<>/))[6,8] } grep {$ship[$F{'goods'}][4] eq (split(/<>/,$_))[0]} @yardline;
	if (!$max_hp) { $max_hp = $ship[$F{'goods'}][1] * 0.2; $price = $ship[$F{'goods'}][1] * 10000; }
	$price = $max_hp ? int($price * 0.03 / ($ship[$F{'goods'}][2] / $max_hp)) : 0;
	if ( $money < $price ) { &play("����������܂���"); exit }
	if ($ship[$F{'goods'}][1] > 500) { $down = 20 }
	elsif ($ship[$F{'goods'}][1] > 100) { $down = 10 }
	if ( ($total - $total_load - $food - $sailor - $down) < 0 ) {
		&play("�c�ωׂ�����܂���");
		return
	}
	$action = '';
	$ship[$F{'goods'}][1] = $ship[$F{'goods'}][1] - $down;
	splice(@ship_ind , $F{'goods'} ,1 ,"$ship[$F{'goods'}][0],$ship[$F{'goods'}][1],$max_hp,$ship[$F{'goods'}][3],$ship[$F{'goods'}][4]");
	$money -= $price;
	&msg("$ship[$F{'goods'}][4]���C�����܂���");
	&add_record("$ship[$F{'goods'}][4]�� $price�� �C��");
	&play;
}

1;