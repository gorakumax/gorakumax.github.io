# Sub Get City #
sub get_city {
	open(IN,"$citydir\/$port\.dat") || &check_city;
	$cityline = <IN>;
	close(IN);
	if ($no_city) { return }
	if (!$cityline) { &error("City file �ǂ݂��݃G���[") }
	($owner,$owname,$cname,$chp,$cmoney,$cload,$cship,$citem,$cintro,$crate,$csell,$buyer) = split(/<>/,$cityline);
}

# Sub Set City #
sub set_city {
	&set_me;
	$cityline = join('<>',$owner,$owname,$cname,$chp,$cmoney,$cload,$cship,$citem,$cintro,$crate,$csell,$buyer);
	&write_dat("$citydir\/$port\.dat",$cityline);
}

# Sub Check City #
sub check_city {
	$no_city = 1;
}

1;