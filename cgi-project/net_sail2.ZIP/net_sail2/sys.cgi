# Sub Get Me #
sub get_me {
	return if $getmeflag;
	@ilines = &open_dat("$usrdir\/$_[0]\.dat","ID������܂���");
	if (!@ilines) { &error("ID $_[0] �ǂ݂��݃G���[") }
	$userline = shift(@ilines);
	($id,$name,$pass,$sex,$money,$atk,$cmd,$nav,$adven,$piracy,$trade,$food,$sailor,$load,$ship_line,
	 $area,$port,$point,$tactics,$record,$quest_flag,$quest_line,$friend_line,$battle_line,
	 $last,$moved,$end_quest,$intro,$mail,$url,$host,$os,$ip,$bz,$action,$item_line,$city_line,$reserv,$aexp,$pexp,$texp) = split(/<>/,$userline);
	@ship_ind = split(/��/,$ship_line);
	$t_item = 0;
	while ($item_line =~ /,/g) { $t_item++; }
	if ($F{'ps'} eq $adps)	    { $error = 1 }
	if (&get_crypt($F{'ps'},$pass)) { $error = 1 }
	&error("�p�X���[�h���Ⴂ�܂�") if !$error;
	undef $userline;
	$getmeflag = 1;
}

# Sub Get U #
sub get_u {
	undef $dead;

	eval {
		open(IN,"$usrdir\/$_[0]\.dat") || &fr_del($_[0]);
		flock(IN,1);
	};

	if ($@) {
		&lock;
		open(IN,"$usrdir\/$_[0]\.dat") || &fr_del($_[0]);
	}
	@ulines = <IN>;
	close(IN);
	if ($@) {
		&unlock;
		undef $@;
	}
	return(0) if $dead;
	$userline = shift(@ulines);
	($uid,$uname,$upass,$usex,$umoney,$uatk,$ucmd,$unav,$uadven,$upiracy,$utrade,$ufood,$usailor,$uload,$uship_line,
	 $uarea,$uport,$upoint,$utactics,$urecord,$uquest_flag,$uquest_line,$ufriend_line,$ubattle_line,
	 $ulast,$umoved,$uend_quest,$uintro,$umail,$uurl,$uhost,$uos,$uip,$ubz,$uaction,$uitem_line,$ucity_line,$ureserv,$uaexp,$upexp,$utexp) = split(/<>/,$userline);
	@uship_ind = split(/��/,$uship_line);
	$ut_item = 0;
	while ($uitem_line =~ /,/g) { $ut_item++; }
	undef $userline;
	return(1);
}


# Sub Set Me #
sub set_me {
	$ship_line = join('��',@ship_ind);
	$userline  = join('<>',$id,$name,$pass,$sex,$money,$atk,$cmd,$nav,$adven,$piracy,$trade,
				$food,$sailor,$load,$ship_line,$area,$port,$point,$tactics,
				$record,$quest_flag,$quest_line,$friend_line,$battle_line,
				$last,$moved,$end_quest,$intro,$mail,$url,$host,$os,$ip,$bz,$action,$item_line,$city_line,$reserv,$aexp,$pexp,$texp,"\n");
	unshift (@ilines,$userline);
	if (!$id || $#ilines < 0) { return }
	&write_dat("$usrdir\/$id\.dat",@ilines);
	undef $getmeflag;
}

# Sub Set U #
sub set_u {
	$uship_line = join('��',@uship_ind);
	$userline  = join('<>',$uid,$uname,$upass,$usex,$umoney,$uatk,$ucmd,$unav,$uadven,$upiracy,$utrade,
				$ufood,$usailor,$uload,$uship_line,$uarea,$uport,$upoint,$utactics,
				$urecord,$uquest_flag,$uquest_line,$ufriend_line,$ubattle_line,
				$ulast,$umoved,$uend_quest,$uintro,$umail,$uurl,$uhost,$uos,$uip,$ubz,$uaction,$uitem_line,$ucity_line,$ureserv,$uaexp,$upexp,$utexp,"\n");
	unshift (@ulines,$userline);
	if (!$uid || $#ulines < 0) { return }
	&write_dat("$usrdir\/$uid\.dat",@ulines);
}

# Sub Get All Users #
sub get_all_users {
	return if $getallusersflag;
	opendir(DIR,"$usrdir") || &error("���[�U�f�[�^�ǂ݂��݃G���[:$usrdir�Ƃ������O�̃��[�U�f�[�^�p�f�B���N�g�����������p�[�~�b�V�������s���ł�");
	@userfiles = sort grep /\.dat/,readdir(DIR);
	closedir(DIR);
	foreach (@userfiles) {
		open(IN,"$usrdir\/$_") || &error("\/$_���J�����Ƃ��ł��܂���ł���");
		$line = <IN>;
		push(@alllines,$line);
		close(IN);
	}
	$getallusersflag = 1;
}

# Sub Friend Delete #
sub fr_del {
	$dead = 1;
	if ($F{'id'}) {
		&get_me($F{'id'});
		my @friend = split(/��/,$friend_line);
		@friend = grep { $_[0] != (split(/,/))[0] } @friend;
		$friend_line = join('��',@friend);
		&set_me;
		&error("$_[0]�͑��݂��܂���")
	}
	else { &error("$_[0]�͑��݂��܂���") }
}

# Sub Get Cryptogram #
sub get_crypt {
	if (!$def_cp) { if ($_[0] eq $_[1]) { return 1 } else { return 0 } }
	my $salt  = substr($_[1],0,2);
	if ($_[1] eq crypt($_[0],$salt))	{ return 1 } else { return 0 }
}

# Sub Open Dat #
sub open_dat {
	my $type = $_[1] ? $_[1] : "�ǂݍ��݃G���[";
	eval {
		open(IN,"$_[0]") || &error("$type");
		flock(IN,1);
	};

	if ($@) {
		&lock;
		open(IN,"$_[0]") || &error("$type");
	}

	my @lines = <IN>;
	close(IN);
	if ($@) {
		&unlock;
		undef $@;
	}
	return @lines;
}

# Sub Write Dat #
sub write_dat {
	eval {
		open(OUT,">>$_[0]") || &error("�������݃G���[");
		flock(OUT,2);
		truncate(OUT,0);
		seek(OUT,0,0);
	};

	if ($@) {
		&lock;
		open(OUT,">$_[0]") || &error("�������݃G���[");
	}

	shift(@_);
	print OUT @_;
	close(OUT);
	if ($@) {
		&unlock;
		undef $@;
	}
}

# Sub Lock #
sub lock {
	return if !$lockkey;
	my $try = 5;
	&unlock if (-e $lockfile) && (time - (stat($lockfile))[9] > 60);
	if    ($lockkey == 1) {
		while (!mkdir($lockfile,606)) {
			--$try or &error('�r�W�[�ł�');
			sleep(1)
		}
	}
	elsif ($lockkey == 2) {
		while (!symlink(".",$lockfile)) {
			--$try or &error('�r�W�[�ł�');
			sleep(1)
		}
	}
	$locked = 1;
}

# Sub Unlock #
sub unlock {
	if    ($lockkey == 1) { rmdir($lockfile)  }
	elsif ($lockkey == 2) { unlink($lockfile) }
	undef $locked;
}

1;