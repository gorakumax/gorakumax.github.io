# Sub Event Write #
sub event_write {
	&get_date(time) if !$date;
	my @eventlines = &open_dat($eventdat);
	if (@eventlines >= $def_om) { pop @eventlines }
	unshift (@eventlines,"[$date] $_[0]\n")
	&write_dat("$eventdat",@eventlines)
}

1;